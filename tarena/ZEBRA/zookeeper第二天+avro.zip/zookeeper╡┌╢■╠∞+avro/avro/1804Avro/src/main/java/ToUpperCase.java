
public class ToUpperCase {

	public String toUpper(String str){
		return str;
	}
}
